# Projeto Robo - Kit Básico

Repositório completo para o desenvolvimento do robô usando o Kit Básico fornecido.

## Visão geral
Este projeto apresenta um robô móvel baseado em Arduino Mega, capaz de seguir uma linha e desviar de obstáculos usando sensores de linha e um sensor ultrassônico. O repositório contém código-fonte, esquemático, arquivos 3D para impressão, imagens de montagem e um relatório técnico detalhado.

## Estrutura
- `codigo/` - Código fonte (.ino) e notas.
- `esquematico/` - Esquemático elétrico (PNG/PDF).
- `3d/` - Arquivos 3D do chassi (.stl).
- `imagens/` - Fotos e vídeos de montagem/testes.
- `relatorio/` - Relatório técnico completo em Markdown.

## Componentes do Kit
- 1x Chassi impresso em 3D
- 1x Arduino Mega
- 2x Motores 5V com redução
- 1x Ponte H L298N
- 1x Bateria 9V (recomenda-se alternativa com maior capacidade)
- Sensores de linha (2 ou 3 módulos)
- Sensor ultrassônico HC-SR04

## Como usar
1. Abra `codigo/main.ino` na IDE Arduino.
2. Selecione placa: **Arduino Mega 2560**.
3. Conecte o Arduino ao computador e faça upload do sketch.
4. Monte o hardware conforme o esquemático em `esquematico/esquematico.png`.

## Licença
Coloque uma licença (ex: MIT) se desejar compartilhar o projeto publicamente.
