# Relatório Técnico - Projeto Robô (Kit Básico)

## 1. Objetivos
- Projetar e montar um robô móvel simples usando o kit básico fornecido.
- Implementar controle de motores, leitura de sensores de linha e ultrassom.
- Testar comportamento de seguimento de linha e desvio de obstáculos.

## 2. Descrição do Projeto
O robô é baseado em um Arduino Mega que comanda dois motores DC via ponte H L298N. Sensores de linha detectam contraste para seguir um traço no chão. Um sensor ultrassônico HC-SR04 é usado para detectar obstáculos à frente e acionar manobras de desvio.

## 3. Componentes
- Chassi impresso em 3D — suporte mecânico.
- Arduino Mega — microcontrolador.
- 2x Motor DC 5V com redução.
- L298N — driver de motores.
- Bateria 9V (recomenda-se pack AA ou Li-ion para testes longos).
- Sensores de linha (módulos digitais).
- HC-SR04 — sensor ultrassônico.

## 4. Programação
O arquivo `codigo/main.ino` contém a lógica principal: leituras dos sensores, decisão reativa e controle dos motores. Parâmetros importantes: `BASE_SPEED`, `TURN_SPEED` e `DIST_THRESHOLD`.

## 5. Montagem
### Mecânica
1. Imprima o chassi (`3d/chassi.stl`) em PLA.
2. Fixe motores e rodas no chassi.
3. Parafuse driver e Arduino no chassi.

### Elétrica
1. Conecte motores às saídas do L298N.
2. Ligue alimentação 9V à entrada do L298N (Vmotor) e conecte GND ao Arduino.
3. Ligue ENA/ENB a pinos PWM (5 e 6) e IN1..IN4 aos pinos digitais 22-25.
4. Ligue sensores de linha nos pinos 8 e 9.
5. Conecte TRIG/ECHO do HC-SR04 aos pinos 10 e 11.

## 6. Estratégia de Controle
Comportamento reativo com prioridade para detecção de obstáculos. Futuras melhorias incluem PID, encoders e comunicação sem fio.

## 7. Testes
Descrever testes de movimentação, seguidor de linha e desvio de obstáculos. Registrar tempos e ajustes de parâmetros.

## 8. Conclusões
Avaliação e recomendações: substituir bateria 9V por pack mais capaz, calibração dos sensores, possível melhoraria do chassi.

## 9. Anexos
- Código: `codigo/main.ino`
- Esquemático: `esquematico/esquematico.png`
- Arquivos 3D: `3d/chassi.stl`
- Imagens: `imagens/`
