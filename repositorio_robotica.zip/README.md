# Projeto Robo - Kit Básico

Repositório completo para o desenvolvimento do robô usando o Kit Básico fornecido.
